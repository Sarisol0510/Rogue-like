﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlimeKing : MonoBehaviour
{
    Rigidbody2D rigid;
    PlayerMove GetPlayer;

    public float monsterHP = 10000000;
    public GameObject explosion;
    void Start()
    {
        
    }


    void Update()
    {
        if (monsterHP <= 0)
        {
            GameObject explo = Instantiate(explosion, transform.position, transform.rotation);
            Destroy(explo, 1f);
            Destroy(gameObject);
            GetPlayer.exp++;
        }
    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.transform.tag == "Damage")
        {
            GetPlayer = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerMove>();
            GameObject explo = Instantiate(explosion, transform.position, transform.rotation);
            monsterHP = monsterHP - 10 - 10 * GetPlayer.attack;
            Destroy(explo, 1f);
            Destroy(collision.gameObject);
            rigid.velocity = new Vector2(0f * rigid.velocity.normalized.x, rigid.velocity.y);
        }
        if (collision.transform.tag == "Skill")
        {
            GetPlayer = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerMove>();
            GameObject explo = Instantiate(explosion, transform.position, transform.rotation);
            monsterHP = monsterHP - 10 - 10 * GetPlayer.magic;
            Destroy(explo, 1f);
        }
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.transform.tag == "Player")
        {
            Player_HP PH = GameObject.Find("HP bar").GetComponent<Player_HP>();
            GameObject explo = Instantiate(explosion, transform.position, transform.rotation);
            Destroy(explo, 1f);
            Destroy(gameObject);
            PH.player_hp--;
        }
    }
}
