﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BossHP : MonoBehaviour
{
    public Image hpbar;
    public Text HpText;
    public GameObject GOpanel;

    public float boss_max_hp = GameObject.Find("SlimeKing").GetComponent<SlimeKing>().monsterHP;
    public float boss_hp;

    void Update()
    {
        float boss_hp = GameObject.Find("SlimeKing").GetComponent<SlimeKing>().monsterHP;
        PlayerHPbar();
        if (boss_hp == 0)
        {
            GOpanel.SetActive(true);
        }
    }



    public void PlayerHPbar()

    {

        hpbar.fillAmount = boss_hp / boss_max_hp;


    }
}
