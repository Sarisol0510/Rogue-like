﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class itemRotate : MonoBehaviour {
	public float X_Rotation=0;
	public float Y_Rotation=0;
	public float Z_Rotation=0;
	void Update () {
		transform.Rotate (new Vector3 (X_Rotation, Y_Rotation, Z_Rotation) * Time.deltaTime);
	}
}
