﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject monster;
    public GameObject monster2;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    int time = 0;
    public int cool = 50;
    void Update()
    {
        PlayerMove PM = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerMove>();
        time++;
        if (PM.level < 5)
        {
            if (time >= cool)
            {
                GameObject monster_1 = Instantiate(monster, transform.position, transform.rotation);
                time = 0;
            }
        }
        if (PM.level >= 5)
        {
            int ran = Random.Range(0, 10);
            if (time >= cool && ran <= 2)
            {
                GameObject monster_2 = Instantiate(monster2, transform.position, transform.rotation);
                time = 0;
            }
            if (time >= cool && ran >= 2)
            {
                GameObject monster_1 = Instantiate(monster, transform.position, transform.rotation);
                time = 0;
            }
        }
    }

}
