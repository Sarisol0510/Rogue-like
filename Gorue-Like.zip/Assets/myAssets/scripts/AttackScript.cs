﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackScript : MonoBehaviour
{
    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.transform.tag == "monster")
        {
            Destroy(gameObject);
            Destroy(collision.gameObject);
        }
    }

}
