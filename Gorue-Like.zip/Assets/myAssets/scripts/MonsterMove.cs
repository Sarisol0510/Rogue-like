﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterMove : MonoBehaviour
{
    Rigidbody2D rigid;
    PlayerMove GetPlayer;

    public GameObject explosion;

    public float speed = 1f;
    public float move_cool = 30;

    public float monsterHP = 50;

    int time = 0;
    void Awake()
    {
        rigid = GetComponent<Rigidbody2D>();
    }
    // Update is called once per frame
    void FixedUpdate()
    {
        time++;
        if (time == move_cool)
        {
            time = 0;
            int direct = Random.Range(-1, 2);
            if (direct != 0)
            {
                rigid.AddForce(new Vector2(direct, 0) * speed, ForceMode2D.Impulse);
                transform.localScale = new Vector3(1.93167f * direct * -1f, transform.localScale.y, transform.localScale.z);
            }else rigid.velocity = new Vector2(rigid.velocity.x, 5);
        }
        if (monsterHP <= 0)
        {
            GameObject explo = Instantiate(explosion, transform.position, transform.rotation);
            Destroy(explo, 1f);
            Destroy(gameObject);
            GetPlayer.exp++;
        }
    }

    //for damage
    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.transform.tag == "Damage")
        {
            GetPlayer = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerMove>();
            GameObject explo = Instantiate(explosion, transform.position, transform.rotation);
            monsterHP = monsterHP -10 - 10 * GetPlayer.attack;
            Destroy(explo,1f);
            Destroy(collision.gameObject);
            rigid.velocity = new Vector2(0f * rigid.velocity.normalized.x, rigid.velocity.y);
        }
        if (collision.transform.tag == "Skill")
        {
            GetPlayer = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerMove>();
            GameObject explo = Instantiate(explosion, transform.position, transform.rotation);
            monsterHP = monsterHP - 10 - 10 * GetPlayer.magic;
            Destroy(explo, 1f);
            rigid.velocity = new Vector2(0f * rigid.velocity.normalized.x, rigid.velocity.y);
        }
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.transform.tag == "Player")
        {
            Player_HP PH = GameObject.Find("HP bar").GetComponent<Player_HP>();
            GameObject explo = Instantiate(explosion, transform.position, transform.rotation);
            Destroy(explo, 1f);
            Destroy(gameObject);
            PH.player_hp--;
        }
    }
}
