﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Detector : MonoBehaviour {
	public float ON = 0;
	private void OnTriggerStay2D (Collider2D col){
			ON = 1;
	}
	private void OnTriggerExit2D (Collider2D col){
			ON = 0;
	}
}
