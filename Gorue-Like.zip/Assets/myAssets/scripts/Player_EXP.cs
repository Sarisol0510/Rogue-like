﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player_EXP : MonoBehaviour
{
    public Image hpbar;

    private float player_max_exp = 0;
    private float player_exp = 0;

    void Start()
    {

    }

    void Update()

    {
        PlayerMove health_p = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerMove>();
        player_max_exp = health_p.level * 10;
        player_exp = health_p.exp;
        PlayerEXPbar();

    }



    public void PlayerEXPbar()

    {

        hpbar.fillAmount = player_exp / player_max_exp;


    }
}
