﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.SceneManagement;
using System.Threading;
using UnityEngine.UI;

public class PlayerMove : MonoBehaviour {

	public float maxSpeed;

    public float exp = 0;
    public Text EXP_text;
    public float level = 1;
    public Text Level_text;
    
    public GameObject stat_panel;
    public float health = 0;
    public float attack = 0;
    public float magic= 0;
    public float speed = 0;
    public GameObject class_panel;
    public Text Class_text;

    public GameObject class1;
    public GameObject class2;
    public GameObject class3;

    public AudioClip[] clip;

	SpriteRenderer spriteRenderer;
	Animator anim;
	Rigidbody2D rigid;
	AudioSource audi;

    public GameObject attack_ragne;
    public GameObject skill1;
    public float attack_time = 1000f;
    public float attack_cooltime = 20;
    public float skill1_time = 1000f;
    public float skill1_cooltime = 60;

    void Awake(){
		rigid = GetComponent<Rigidbody2D>();
		spriteRenderer = GetComponent<SpriteRenderer>();
		anim = GetComponent<Animator>();
		audi = GetComponent<AudioSource> ();
    }


	void Update(){
		Detector IsGround = GameObject.Find ("GroundDetector").GetComponent<Detector> ();

	
		if (Input.GetButtonUp ("Horizontal")) {//stop sliding
			rigid.velocity = new Vector2 (0.5f * rigid.velocity.normalized.x, rigid.velocity.y);
		}
		if (Input.GetButtonDown ("Jump") && IsGround.ON==1f) {//Jump
			rigid.velocity = new Vector2 (rigid.velocity.x, 14);
			//PlaySE (0);
		}
		

		if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.LeftArrow)) {//set walking anim
			anim.SetBool ("isWalk", true);
		}
		else
			anim.SetBool ("isWalk", false);

		if (rigid.velocity.y > 0.3f) {//set Jump anim
			anim.SetBool ("isJump", true);
		}else
			anim.SetBool ("isJump", false);


   
    }

	public float direct = 0;
	public float velop = 0;
	void FixedUpdate () {

		float h = Input.GetAxisRaw ("Horizontal");

		rigid.AddForce (Vector2.right*h*10 , ForceMode2D.Impulse);//basic move

		velop = rigid.velocity.x;
		if (rigid.velocity.x <= -0.1) {//set walking anim
			direct = -1;
            transform.localScale = new Vector3(-1, 1, 1);
		}
		if (rigid.velocity.x >= 0.1) {//set walking anim
			direct = 1;
            transform.localScale = new Vector3(1, 1, 1);
        }
		//spriteRenderer.flipX = Input.GetAxisRaw ("Horizontal") == -direct;

		if (rigid.velocity.x > maxSpeed) { //right v limit
			rigid.velocity = new Vector2 (maxSpeed, rigid.velocity.y);
		}

		else if (rigid.velocity.x < maxSpeed*(-1)) { //left v limit
			rigid.velocity = new Vector2 (maxSpeed*(-1), rigid.velocity.y);
		}

		if (Math.Abs(rigid.velocity.x)>0.2f&&musicCode<=8&&rigid.velocity.y < 0.3f) {//set walking sound
			musicCode++;
		}
		if (Math.Abs(rigid.velocity.x)>0.2f&&musicCode==9&&rigid.velocity.y < 0.3f) {//set walking sound
			//PlaySE (2);
			musicCode = 0;
		}
        //////////////////////////////attack////////////////////////////////
        if (Input.GetKey(KeyCode.A) && attack_time >= attack_cooltime && anim.GetCurrentAnimatorStateInfo(0).nameHash != Animator.StringToHash("Base Layer.attack"))
        {
            anim.SetBool("isAttack", true);
            attack_time = 0;
        }
        if (anim.GetCurrentAnimatorStateInfo(0).nameHash == Animator.StringToHash("Base Layer.attack"))
        {
            anim.SetBool("isAttack", false);
        }
        if (attack_time == 10f)
        {
            GameObject attack = Instantiate(attack_ragne, transform.position, transform.rotation);
            attack.transform.parent = transform;
            attack.transform.localScale = new Vector3 (attack.transform.localScale.x * direct, attack.transform.localScale.y, attack.transform.localScale.z);
            Destroy(attack, 0.1f);
        }
        if (attack_time >= 0)
        {
            attack_time++;
        }
        ///////////////////////////////skill1/////////////////////////
        if (Input.GetKey(KeyCode.S) && skill1_time >= skill1_cooltime && anim.GetCurrentAnimatorStateInfo(0).nameHash != Animator.StringToHash("Base Layer.attack"))
        {
            anim.SetBool("isAttack", true);
            skill1_time = 0;
        }
        if (anim.GetCurrentAnimatorStateInfo(0).nameHash == Animator.StringToHash("Base Layer.attack"))
        {
            anim.SetBool("isAttack", false);
        }
        if (skill1_time == 10f)
        {
            GameObject attack = Instantiate(skill1, new Vector3(transform.position.x -2 * direct, transform.position.y, transform.position.z), transform.rotation);
            attack.transform.parent = transform;
            attack.transform.localScale = new Vector3(attack.transform.localScale.x * direct, attack.transform.localScale.y, attack.transform.localScale.z);
            attack.GetComponent<Rigidbody2D>().AddForce(new Vector2(direct, 0) * 5, ForceMode2D.Impulse);
            attack.transform.parent = null;
            Destroy(attack, 1f);
        }
        if (skill1_time >= 0)
        {
            skill1_time++;
        }
        //exp
        //EXP_text.text = "EXP : " + exp;
        //level
        if (exp >= level * 10)
        {
            level++;
            exp = 0;
            stat_panel.SetActive(true);
        }
        Level_text.text = "Level : " + level;

        //Class
        if(health == 10)
        {
            GameObject player = Instantiate(class1, new Vector3(transform.position.x , transform.position.y, transform.position.z), transform.rotation);
            CameraMove MC = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<CameraMove>();
            MC._target = player.transform;
            Destroy(gameObject);
            PlayerMove PM = player.GetComponent<PlayerMove>();
            PM.Level_text = GameObject.Find("LEvel").transform.GetComponent<Text>();
            PM.stat_panel = GameObject.Find("Canvas").transform.Find("Stat_Panel").gameObject;
            PM.class_panel = GameObject.Find("Canvas").transform.Find("Classup_Panel").gameObject;
            PM.Class_text = GameObject.Find("Canvas").transform.Find("Classup_Panel").Find("Classup_Text").transform.GetComponent<Text>();
            class_panel.SetActive(true);
            Class_text.text = "You are now Holy Knight";
            PM.StartCoroutine(FadeTextToFullAlpha());
        }
        if (attack == 10)
        {
            class_panel.SetActive(true);
            Class_text.text = "You are now Fencer";
            StartCoroutine(FadeTextToFullAlpha());
            attack = 30;
            GameObject player = Instantiate(class2, new Vector3(transform.position.x, transform.position.y, transform.position.z), transform.rotation);
            CameraMove MC = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<CameraMove>();
            MC._target = player.transform;
            Destroy(gameObject);
            PlayerMove PM = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerMove>();
            PM.Level_text = GameObject.Find("LEvel").transform.GetComponent<Text>();
            PM.stat_panel = GameObject.Find("Stat_Panel");
            PM.class_panel = GameObject.Find("Classup_Panel");
            PM.Class_text = GameObject.Find("Classup_Text").transform.GetComponent<Text>();
        }
        if (magic == 10)
        {
            class_panel.SetActive(true);
            Class_text.text = "You are now Magic Knight";
            StartCoroutine(FadeTextToFullAlpha());
            magic = 30;
            GameObject player = Instantiate(class3, new Vector3(transform.position.x, transform.position.y, transform.position.z), transform.rotation);
            CameraMove MC = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<CameraMove>();
            MC._target = player.transform;
            Destroy(gameObject);
            PlayerMove PM = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerMove>();
            PM.Level_text = GameObject.Find("LEvel").transform.GetComponent<Text>();
            PM.stat_panel = GameObject.Find("Stat_Panel");
            PM.class_panel = GameObject.Find("Classup_Panel");
            PM.Class_text = GameObject.Find("Classup_Text").transform.GetComponent<Text>();
        }
        if (speed == 10)
        {
            class_panel.SetActive(true);
            Class_text.text = "You are now Assassin";
            StartCoroutine(FadeTextToFullAlpha());
            speed = 30;
        }
    }


	public int musicCode = 0; 
	public void PlaySE(int a)
	{
		audi.clip = clip [a];
		audi.Play ();
	}
    public void Raise_Stat(string name)
    {
        if(name == "health")
        {
            health++;
            Player_HP PH = GameObject.Find("HP bar").GetComponent<Player_HP>();
            PH.player_hp = PH.player_max_hp  + 1;
        }
        if (name == "attack")
        {
            attack++;
        }
        if (name == "magic")
        {
            magic++;
        }
        if (name == "speed")
        {
            speed++;
        }
    }


    public IEnumerator FadeTextToFullAlpha() // 알파값 0에서 1로 전환
    {
        Class_text.color = new Color(Class_text.color.r, Class_text.color.g, Class_text.color.b, 0);
        while (Class_text.color.a < 1.0f)
        {
            Class_text.color = new Color(Class_text.color.r, Class_text.color.g, Class_text.color.b, Class_text.color.a + (Time.deltaTime / 2.0f));
            yield return null;
        }
        StartCoroutine(FadeTextToZero());
    }

    public IEnumerator FadeTextToZero()  // 알파값 1에서 0으로 전환
    {
        Class_text.color = new Color(Class_text.color.r, Class_text.color.g, Class_text.color.b, 1);
        while (Class_text.color.a > 0.0f)
        {
            Class_text.color = new Color(Class_text.color.r, Class_text.color.g, Class_text.color.b, Class_text.color.a - (Time.deltaTime / 2.0f));
            yield return null;
        }
    }

}