﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player_HP : MonoBehaviour
{
    public Image hpbar;
    public Text HpText;
    public GameObject GOpanel;

    public float player_max_hp=0;
    public float player_hp=0;

    void Start()
    {
        player_hp = player_max_hp + 3f;

    }

    void Update()

    {
        PlayerMove health_p = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerMove>();
        player_max_hp = health_p.health + 3f;
        PlayerHPbar();
        if(player_hp == 0)
        {
            GOpanel.SetActive(true);
            Destroy(GameObject.FindGameObjectWithTag("Player"));
        }
    }



    public void PlayerHPbar()

    {

        hpbar.fillAmount = player_hp/player_max_hp;

        HpText.text = player_hp.ToString();

    }
}
